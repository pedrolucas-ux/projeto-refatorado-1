import express from 'express';
import { PrismaClient } from '@prisma/client';
import { OrderController } from './controllers/OrderController';
import { PrismaOrderRepository } from './repositories/PrismaOrderRepository';
import { EtherealMailProvider } from './providers/EtherealMailProvider';
import { NotificationService } from './services/NotificationService';
import { OrderService } from './services/OrderService';

const app = express();
app.use(express.json());

const prisma = new PrismaClient();
const repository = new PrismaOrderRepository(prisma);
const mailProvider = new EtherealMailProvider();
const notificationService = new NotificationService(mailProvider);
const orderService = new OrderService(repository, notificationService);
const orderController = new OrderController(orderService);

app.post('/orders', orderController.processOrder);

export default app;
