import { IMailProvider } from '../providers/IMailProvider';

type OrderNotification = {
  id: number;
  customer: string;
  total: number;
  products: string[];
};

export class NotificationService {
  constructor(private readonly mailProvider: IMailProvider) {}

  async orderConfirmed(order: OrderNotification): Promise<string | undefined> {
    const names = order.products.map(name => `<li>${name}</li>`).join('');
    return this.mailProvider.sendMail({
      to: order.customer,
      subject: `Confirmação do Pedido #${order.id}`,
      text: `Olá, seu pedido #${order.id} foi confirmado. Total: R$ ${order.total.toFixed(2)}.`,
      html: `<h1>Pedido confirmado!</h1><p>Pedido <b>#${order.id}</b> confirmado.</p><p>Total: <strong>R$ ${order.total.toFixed(2)}</strong></p><ul>${names}</ul>`,
    });
  }
}
