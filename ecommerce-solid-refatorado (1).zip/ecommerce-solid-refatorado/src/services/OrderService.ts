import { IOrderRepository } from '../repositories/IOrderRepository';
import { NotificationService } from './NotificationService';
import { ProductFactory } from '../domain/ProductFactory';
import { PaymentFactory } from '../payments/PaymentFactory';
import logger from '../lib/logger';

type OrderItemInput = { productId: number; quantity: number };
type OrderInput = {
  customer: string;
  items: OrderItemInput[];
  paymentMethod: string;
  paymentDetails?: Record<string, unknown>;
};

export class OrderService {
  constructor(
    private readonly repository: IOrderRepository,
    private readonly notifications: NotificationService,
  ) {}

  async create(input: OrderInput) {
    if (!input.customer || !/^\\S+@\\S+\\.\\S+$/.test(input.customer)) {
      throw new Error('Email do cliente inválido');
    }
    if (!Array.isArray(input.items) || input.items.length === 0) {
      throw new Error('Carrinho vazio');
    }
    for (const item of input.items) {
      if (!Number.isInteger(item.productId) || !Number.isInteger(item.quantity) || item.quantity <= 0) {
        throw new Error('Itens do pedido inválidos');
      }
    }

    const payment = PaymentFactory.create(input.paymentMethod);
    await payment.process(input.paymentDetails);

    let total = 0;
    const products: Array<{ id: number; name: string; price: number; quantity: number; freight: number }> = [];
    for (const item of input.items) {
      const data = await this.repository.findProductById(item.productId);
      if (!data) throw new Error(`Produto ${item.productId} não encontrado`);
      const product = ProductFactory.createProduct(data);
      const freight = product.calculateFreight();
      total += product.price * item.quantity + freight;
      products.push({ id: product.id, name: product.name, price: product.price, quantity: item.quantity, freight });
    }

    const order = await this.repository.createOrder({
      customer: input.customer,
      items: JSON.stringify(products),
      total,
      status: 'confirmed',
    });

    let emailPreview: string | undefined;
    try {
      emailPreview = await this.notifications.orderConfirmed({
        id: order.id, customer: order.customer, total, products: products.map(p => p.name),
      });
    } catch (error) {
      // A falha de email não desfaz um pedido já salvo.
      logger.error(`Pedido ${order.id} salvo, mas a notificação falhou: ${String(error)}`);
    }

    return { orderId: order.id, total, status: order.status, emailPreview };
  }
}
