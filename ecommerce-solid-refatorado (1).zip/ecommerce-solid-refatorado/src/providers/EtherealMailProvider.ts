import nodemailer from 'nodemailer';
import { IMailProvider, MailMessage } from './IMailProvider';
import { getMailClient } from '../lib/mail';
import logger from '../lib/logger';

export class EtherealMailProvider implements IMailProvider {
  async sendMail(message: MailMessage): Promise<string | undefined> {
    const mailer = await getMailClient();
    const info = await mailer.sendMail({
      from: '"DevStore" <noreply@devstore.com>',
      ...message,
    });
    const preview = nodemailer.getTestMessageUrl(info) || undefined;
    logger.info(`Email de teste enviado${preview ? `: ${preview}` : ''}`);
    return preview;
  }
}
