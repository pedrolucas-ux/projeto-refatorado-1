import { IProduct } from './IProduct';
import { PhysicalProduct } from './PhysicalProduct';
import { DigitalProduct } from './DigitalProduct';

type ProductData = { id: number; name: string; price: number; type: string };

export class ProductFactory {
  static createProduct(data: ProductData): IProduct {
    if (data.type === 'physical') {
      return new PhysicalProduct(data.id, data.name, data.price);
    }
    if (data.type === 'digital') {
      return new DigitalProduct(data.id, data.name, data.price);
    }
    throw new Error(`Tipo de produto desconhecido: ${data.type}`);
  }
}
