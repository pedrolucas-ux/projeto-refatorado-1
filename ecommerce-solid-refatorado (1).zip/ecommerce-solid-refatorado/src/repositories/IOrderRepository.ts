export type ProductRecord = {
  id: number;
  name: string;
  type: string;
  price: number;
};

export type CreateOrderData = {
  customer: string;
  items: string;
  total: number;
  status: string;
};

export interface IOrderRepository {
  findProductById(id: number): Promise<ProductRecord | null>;
  createOrder(data: CreateOrderData): Promise<{ id: number; customer: string; items: string; total: number; status: string }>;
}
