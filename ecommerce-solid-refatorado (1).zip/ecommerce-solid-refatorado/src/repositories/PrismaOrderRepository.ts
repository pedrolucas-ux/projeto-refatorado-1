import { PrismaClient } from '@prisma/client';
import { IOrderRepository, ProductRecord, CreateOrderData } from './IOrderRepository';

export class PrismaOrderRepository implements IOrderRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async findProductById(id: number): Promise<ProductRecord | null> {
    return this.prisma.product.findUnique({ where: { id } });
  }

  async createOrder(data: CreateOrderData) {
    return this.prisma.order.create({ data });
  }
}
