import { IPaymentMethod } from './IPaymentMethod';
import { CreditCardPayment } from './CreditCardPayment';
import { PixPayment } from './PixPayment';

export class PaymentFactory {
  static create(method: string): IPaymentMethod {
    switch (method) {
      case 'credit_card': return new CreditCardPayment();
      case 'pix': return new PixPayment();
      default: throw new Error('Método de pagamento não suportado');
    }
  }
}
