export interface IPaymentMethod {
  process(details?: Record<string, unknown>): Promise<void>;
}
