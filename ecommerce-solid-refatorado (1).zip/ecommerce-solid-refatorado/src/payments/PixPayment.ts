import { IPaymentMethod } from './IPaymentMethod';
import logger from '../lib/logger';

export class PixPayment implements IPaymentMethod {
  async process(): Promise<void> {
    // Simulação didática: em produção, integrar com um gateway Pix.
    logger.info('Pagamento Pix processado (simulação)');
  }
}
