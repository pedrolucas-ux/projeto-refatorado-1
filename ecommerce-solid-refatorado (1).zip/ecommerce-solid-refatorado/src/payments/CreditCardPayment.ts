import { IPaymentMethod } from './IPaymentMethod';
import logger from '../lib/logger';

export class CreditCardPayment implements IPaymentMethod {
  async process(details: Record<string, unknown> = {}): Promise<void> {
    const cvv = String(details.cvv ?? '');
    const cardNumber = String(details.cardNumber ?? '');
    if (!/^\\d{13,19}$/.test(cardNumber) || !/^\\d{3,4}$/.test(cvv)) {
      throw new Error('Dados do cartão inválidos');
    }
    if (cvv === '000') throw new Error('Cartão recusado');
    logger.info(`Pagamento com cartão final ${cardNumber.slice(-4)}`);
  }
}
