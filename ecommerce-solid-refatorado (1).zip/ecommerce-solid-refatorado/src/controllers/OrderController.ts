import { Request, Response } from 'express';
import { OrderService } from '../services/OrderService';
import logger from '../lib/logger';

export class OrderController {
  constructor(private readonly orderService: OrderService) {}

  processOrder = async (req: Request, res: Response): Promise<Response> => {
    try {
      const result = await this.orderService.create(req.body);
      return res.status(201).json({ message: 'Pedido processado com sucesso', ...result });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Erro interno';
      logger.error(`Erro ao processar pedido: ${message}`);
      const clientErrors = [
        'Carrinho vazio', 'Email do cliente inválido', 'Itens do pedido inválidos',
        'Método de pagamento não suportado', 'Dados do cartão inválidos', 'Cartão recusado',
      ];
      if (message.startsWith('Produto ') || clientErrors.includes(message)) {
        return res.status(400).json({ error: message });
      }
      return res.status(500).json({ error: 'Erro interno' });
    }
  };
}
