# E-commerce refatorado com SOLID

## Como executar
```bash
npm install
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm run dev
```
API em `http://localhost:3000`.

## Testes
Livro físico (ID 1; preço R$ 100,00 + frete R$ 10,00):
```bash
curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"customer":"cliente@exemplo.com","items":[{"productId":1,"quantity":1}],"paymentMethod":"credit_card","paymentDetails":{"cardNumber":"1234567812345678","cvv":"123"}}'
```

E-book (ID 2; preço R$ 50,00 e frete zero):
```bash
curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"customer":"cliente@exemplo.com","items":[{"productId":2,"quantity":1}],"paymentMethod":"pix"}'
```

Cartão recusado para simulação: use `"cvv":"000"`. Pix é simulado; não há integração financeira real.

## O que foi refatorado
- **SRP:** Controller lida com HTTP; OrderService orquestra; NotificationService monta a notificação; provider envia email.
- **OCP:** pagamentos implementam `IPaymentMethod`; `CreditCardPayment` e `PixPayment` são estratégias separadas.
- **LSP:** produtos físicos e digitais implementam `IProduct`; cada um define `calculateFreight()`.
- **DIP:** `OrderService` depende de `IOrderRepository`, e o serviço de notificação depende de `IMailProvider`.
- **Repository:** Prisma está isolado em `PrismaOrderRepository`.
- **Factory:** `ProductFactory` transforma registros do banco em objetos de domínio.
- **Validação:** email, carrinho, quantidades e dados de cartão são verificados.

O frete é calculado por unidade de produto físico no fluxo atual (R$ 10 por item da linha, não por unidade de quantidade). Para múltiplas unidades, ajuste `freight * quantity` se essa for a regra desejada.
